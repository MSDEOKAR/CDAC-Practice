package com.cdac.acts;

public class StringTester {
	
	public static void main(String[] args) {
		String str1 = "CDAC";
		System.out.println(str1);
		String str2 = "CDAC";
		System.out.println(str2);
		String str3 = "ACTS";
		System.out.println(str3);
		String str4 = "ACTS";
		System.out.println(str4);
		
		String str5 = new String("ACTS");
		System.out.println(str5);
		
		
	}

}
