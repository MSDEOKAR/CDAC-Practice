package com.acts;

public class B{
	private String bPri;
	protected String bPro;
	String bDef;
	public String bPub;

	public void bMethod() {

	}
}
