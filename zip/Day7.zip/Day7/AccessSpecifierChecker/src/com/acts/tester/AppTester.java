package com.acts.tester;

public class AppTester {

	public static void main(String[] args) {
		//A a = new A();
	}
}
