public class EnumInternalsTester {
	public static void main(String[] args) {
		//Printing enum
		DayEnum today = DayEnum.FRIDAY;
		System.out.println(today);
		System.out.println(today.ordinal());
		System.out.println(today.name());
		
	}

}
