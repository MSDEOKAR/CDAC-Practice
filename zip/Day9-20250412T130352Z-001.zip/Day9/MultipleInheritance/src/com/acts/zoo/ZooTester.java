package com.acts.zoo;

public class ZooTester {

	public static void main(String[] args) {

		Animal liger = new Liger();
		liger.walk();
	}

}
