package com.acts.bank.exception;


@SuppressWarnings("serial")
public class MinBalanceException extends Exception{
	
	public MinBalanceException(String msg) {
		super(msg);
	}
	
}
