package com.cdac.acts;

public class C implements I1, I2{

	@Override
	public void methodI1() {
		System.out.println("C::methodI1");
		
	}

	@Override
	public void methodI2() {
		System.out.println("C::methodI1");
		
	}
	
	public static void main(String[] args) {
		
	}

}
