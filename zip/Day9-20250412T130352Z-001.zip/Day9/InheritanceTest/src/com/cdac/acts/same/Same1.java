package com.cdac.acts.same;

public interface Same1 extends SameParent, Same2 {
	void methodSame1();
}
