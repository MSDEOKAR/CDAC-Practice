package com.cdac.acts;

public interface I2 extends I1{
	void methodI2();
}
