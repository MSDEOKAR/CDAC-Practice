package com.cdac.acts;

public class A {

	public void methodA1() {
		System.out.println("method A1");
	}
}
