package com.cdac.acts;

public interface I3 extends I1, I2{
	void methodI3();
}
