package com.cdac.acts.same;

public interface Same2 extends SameParent{
	void methodSame2();
}
