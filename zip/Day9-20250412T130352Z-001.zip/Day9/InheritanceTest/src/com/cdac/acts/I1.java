package com.cdac.acts;
@FunctionalInterface
public interface I1 {
	void methodI1();
}
