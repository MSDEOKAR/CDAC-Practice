package com.cdac.acts;

public class D implements I3 {

	@Override
	public void methodI1() {
		System.out.println("D::methodI1");
	}

	@Override
	public void methodI2() {
		System.out.println("D::methodI1");
	}

	@Override
	public void methodI3() {
		System.out.println("D::methodI1");
	}
	
	public static void main(String[] args) {
		
	}

}
