package com.cdac.acts.same;

public interface SameParent {
	void method();
}
