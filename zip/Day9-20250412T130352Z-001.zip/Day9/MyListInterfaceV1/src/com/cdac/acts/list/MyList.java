package com.cdac.acts.list;

public interface MyList {
	void insert(int element);
	int retrieve(int index);
}
