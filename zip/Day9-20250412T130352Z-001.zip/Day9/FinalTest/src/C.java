
final public class C {

	public void method3() {
		System.out.println("A final");
	}
}
