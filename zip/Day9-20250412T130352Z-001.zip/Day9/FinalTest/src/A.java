
public class A {
	
	final public void method1() {
		System.out.println("A final");
	}
}
