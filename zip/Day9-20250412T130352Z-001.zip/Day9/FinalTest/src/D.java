
public class D extends C {

	public void method3() {
		System.out.println("A final");
	}
}
