
public class B extends A {

	@Override
	public void method1() {
		System.out.println("A final");
	}
}
