
public class Tester {

	public static void main(String[] args) {
		
		I1 i1 = new Test();
		i1.method1();
		I2 i2 = new Test();
		i2.method1();

	}

}
