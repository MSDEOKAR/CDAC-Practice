
public interface I1 {
	default void method1() {
		System.out.println("I1");
	}

}
