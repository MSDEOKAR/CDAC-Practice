
public class Test implements I1, I2 {

	@Override
	public void method1() {
	}
	
	
//	@Override
//	public void method1() {
//		System.out.println("Test");
//
//	}

}
