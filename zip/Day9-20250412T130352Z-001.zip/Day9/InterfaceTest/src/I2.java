
public interface I2 {
	default void method1() {
		System.out.println("I2");
	}
}
