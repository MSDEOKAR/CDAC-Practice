public class Test 
{
public static void main(String[] args) 
		{
			byte b=2;
			b =(byte)(b+4);
			b=+4;
			System.out.println(b);
		}
}
