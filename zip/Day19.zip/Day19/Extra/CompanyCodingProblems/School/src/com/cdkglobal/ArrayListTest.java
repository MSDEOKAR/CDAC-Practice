package com.cdkglobal;

import java.util.ArrayList;
import java.util.List;


public class ArrayListTest {
public static void main(String[] args) {
	List<?> al = new ArrayList<String>();
	al.add(null);
	//al.add("string1");
	System.out.println(al);
	
}
}
