package com.deutche;
class Base{
	public Object method(){
	return null;
	}
}
public class Overriding extends Base {

	@Override
	public String method()
	{
		return null;
	}
}
