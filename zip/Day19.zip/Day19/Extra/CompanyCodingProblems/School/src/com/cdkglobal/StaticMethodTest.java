package com.cdkglobal;

public class StaticMethodTest {

	public static void show()
	{
		System.out.println("Show method called");
	}
	public static void main(String[] args) {
		StaticMethodTest test = null;
		test.show();
	}

}
