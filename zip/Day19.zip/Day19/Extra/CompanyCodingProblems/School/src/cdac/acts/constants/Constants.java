package cdac.acts.constants;

public interface Constants 
{
	public static String EMPTY_STRING ="";
}
