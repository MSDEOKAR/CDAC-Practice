package others;
class TestClass
{
   public static void main(String args[] )
   {
      String str1 = "str1";
      String str2 = "str2";
      System.out.println( str1.concat(str2) );
      System.out.println(str1);
   }
}
