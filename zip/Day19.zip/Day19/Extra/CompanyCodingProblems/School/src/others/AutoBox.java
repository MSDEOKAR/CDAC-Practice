package others;

public class AutoBox 
{
	public static void main(String[] args) throws Exception
	{
		AutoBox ab = new AutoBox();
	    int autobox = ab.autobox();
	}
	private Integer autobox()
	{
	    return null;
	}
}
