import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;


public class ToggleTest
{
public static void main(String[] args) {
	
	String value;
	int [] arr = new int[]{1,2,3,1,1};
	HashMap<Integer, String> hm = new HashMap<>();
	for(Integer i: arr)
	{
		System.out.println(i);
	}
}
}
