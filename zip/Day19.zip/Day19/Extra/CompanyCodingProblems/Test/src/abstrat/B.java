package abstrat;

public class B extends A{

	@Override
	public void methodA2() 
	{
		
		
	}
	
	@Override
	public void methodA1()
	{
		
	}

}
