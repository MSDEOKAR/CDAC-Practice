package com.acts.method.innerclass;

public class OuterTester {
	public static void main(String[] args) {
		Outer outer = new Outer();
		outer.outerMethod();
	}
}
