package com.acts;

public enum BookType {
	FICTION,
	TECH,
	POLITICS,
	HISTORY,
	THRILLER,
	COMEDY
}
