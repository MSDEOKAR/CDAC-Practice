package com.acts;

public enum CourseEnum {
	PG_DAC,
	PG_DESD,
	PG_VLSI
}
