package com.acts.emp;

import java.util.Date;

public class ContractEmployee extends Employee {

	private double dailyRate;
	private int noOfDays;

	public ContractEmployee() {
		super();
	}

	public ContractEmployee(String name, String title,
			Date doj,double dailyRate, int noOfDays) {
		super(name, title , doj);
		this.dailyRate = dailyRate;
		this.noOfDays = noOfDays;
	}

	@Override
	public double calculateSalary() {
		System.out.println("Contract salary");
		return dailyRate * noOfDays;
	}

	public double getDailyRate() {
		return dailyRate;
	}

	public void setDailyRate(double dailyRate) {
		this.dailyRate = dailyRate;
	}

	public int getNoOfDays() {
		return noOfDays;
	}

	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	
	public static int getCurrentEmpId() {
		//return EMP_ID_START;
		return 300;
	}

	@Override
	public String toString() {
		return "ContractEmployee [" + super.toString() + " dailyRate=" + dailyRate + ", noOfDays=" + noOfDays + "]";
	}
	
}
