package com.acts.emp;

public enum TitleEnum {
	SW_ENGG,
	SR_SW_ENGG,
	TECH_LEAD
}
