package com.acts.txt.io;

public enum BookType {
	FICTION,
	TECH,
	POLITICS,
	HISTORY,
	THRILLER,
	COMEDY
}
