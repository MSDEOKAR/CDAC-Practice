package com.cdac.acts.tester;

import com.cdac.acts.Employee;

public class EmployeeThisTester {
	public static void main(String[] args) {
		Employee employee = new Employee("Sunny", "IT", 44444);
		System.out.println(employee);
		employee.printData();
	}

}
