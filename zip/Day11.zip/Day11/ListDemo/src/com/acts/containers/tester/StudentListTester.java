package com.acts.containers.tester;

import java.util.ArrayList;
import java.util.List;

public class StudentListTester {

	public static void main(String[] args) {
		List<com.acts.Student> studentsList = new ArrayList<>();

	}

}
